const TEST_ENV = require("../../utils/consts")
const puppeteer = require("puppeteer");
const fs = require("fs");
const prisma = require('../../prisma/client');
const cloudinary = require("../../config/clouddinaryConifg");
const multer = require("multer")
const upload = multer({ storage: multer.memoryStorage() });
const ExcelJS = require("exceljs");
const {
  verifierModelesExistants,
  getTpesParc,
  trouverConflitsModele,
  creerTpesEtCompleterModeles,
} = require("../../utils/parcTpeModele");
const { text } = require("stream/consumers");

// baseUrl est l'addresse du site de livraison
const baseUrl = process.env.FRONTEND_BASE_URL || "https://livraisons.greenpayci.com";
// localUrl est l'addresse en local pour les tests
const localUrl = "http://localhost:5173"
// GENERAL_URL va être utilisée dans les mails envoyés pour pouvoir rediriger correctement l'utilisateur vers la page avec le bon lien
// En test GENERAL_URL doit avoir la valeur de localUrl et celle de baseUrl lors du deploiement.
let GENERAL_URL = baseUrl
let test_env = TEST_ENV
if (test_env) {
  GENERAL_URL = localUrl
}

const normalize = (value) => {
  if (value === null || value === undefined) return null;
  return String(value).trim();
};

const extractNumber = (value) => {
  if (value === null || value === undefined) return null;
  const match = String(value).match(/\d+/);
  return match ? parseInt(match[0], 10) : null;
};

// Code stock obligatoire et unique parmi les stocks non supprimés (même règle que le stock depuis le rebut et la réception)
const verifierCodeStock = async (codeStock) => {
  const code = codeStock ? String(codeStock).trim() : ''
  if (!code) return "Vous devez déterminer un code au stock !"
  const memeCode = await prisma.stocks.findFirst({ where: { code_stock: code, is_deleted: false } })
  return memeCode ? "Un stock du même code existe déjà !" : null
}

const addPiece = async (req, res) => {
  try {
    const {
      nomPiece,
      type,
      itemModels,
      itemServices,
      user_id,
    } = req.body

    let utilisateur = null;
    utilisateur = await prisma.users.findUnique({
      where: {
        id_user: parseInt(user_id)
      }
    });
    if (!utilisateur) {
      console.log("Utilisateur non trouvé")
      return res.status(404).json({ message: "Utilisateur non trouvé" });
    }
    let nomUser = utilisateur.fullname

    const nouvellePiece = await prisma.items.create({
      data: {
        nom_piece: nomPiece,
        type: type,
        created_by: nomUser,
        user_id: parseInt(user_id),
        created_at: new Date(),
      }
    })

    const pieceId = nouvellePiece.id_piece

    if (itemModels && Array.isArray(itemModels)) {
      await prisma.items_models.createMany({
        data: itemModels.map(modelId => ({
          item_id: pieceId,
          model_id: modelId,
        })),
      });
    }

    if (itemServices && Array.isArray(itemServices)) {
      await prisma.items_services.createMany({
        data: itemServices.map(serviceId => ({
          item_id: pieceId,
          service_id: serviceId,
        })),
      });
    }

    res.status(201).json({
      message: "Nouvelle pièce enregistrée avec succès",
      stock_dt: nouvellePiece
    });
  } catch (error) {
    console.log("Erreur lors de la création :", error);
    res.status(500).json({ message: "Erreur interne", error });
  }
}

const getAllItems = async (req, res) => {
  try {
    const items = await prisma.items.findMany({
      orderBy: { id_piece: 'desc' },
    });

    res.status(200).json(items);
  } catch (error) {
    res.status(500).json({ message: "Erreur lors de la récupération du stock", error });
  }
}

const createStock = async (req, res) => {
  try {
    const {
      selectedPiece,
      selectedModel,
      selectedService,
      origine,
      codeStock,
      motif,
      detailsMouvement,
      userId,
      commentaire,
    } = req.body

    let utilisateur = null;
    utilisateur = await prisma.users.findUnique({
      where: {
        id_user: parseInt(userId)
      }
    });
    if (!utilisateur) {
      console.log("Utilisateur non trouvé")
      return res.status(404).json({ message: "Utilisateur non trouvé" });
    }

    const erreurCode = await verifierCodeStock(codeStock)
    if (erreurCode) {
      return res.status(400).json({ message: erreurCode });
    }

    const details = typeof detailsMouvement === "string"
      ? JSON.parse(detailsMouvement)
      : detailsMouvement;

    const item = parseInt(selectedPiece)
    const itemModel = parseInt(selectedModel)
    const itemService = parseInt(selectedService)

    let quantite_lot = 0
    let quantite_carton = 0
    let quantite_piece = 0

    let nouveauMouvement = null

    const typeMouvement = details.typeMouvement

    const dateAction = new Date()

    const creationStock = await prisma.$transaction(async (tx) => {
      const nouveauStock = await tx.stocks.create({
        data: {
          code_stock: String(codeStock).trim(),
          piece_id: item,
          model_id: itemModel,
          service_id: itemService,
          quantite_lot,
          quantite_carton,
          quantite_piece,
          created_at: dateAction,
          created_by: utilisateur.id_user,
          last_update: dateAction,
          updated_by: utilisateur.id_user,
          owner: utilisateur.id_user,
        }
      })

      await tx.stock_owners.create({
        data: {
          user_id: parseInt(userId),
          stock_id: nouveauStock.id,
          type: 'owner',
        }
      })

      if (typeMouvement == 5) {
        quantite_piece = details.stockFinalPiece

        nouveauMouvement = await tx.mouvement_stock.create({
          data: {
            type: 'entree',
            mouvement: 5,
            stock_id: nouveauStock.id,
            piece_id: item,
            service_origine: null,
            service_destination: itemService,
            origine,
            model_id: itemModel,
            stock_initial: 0,
            quantite: details.quantiteMouvement,
            stock_final: details.stockFinalPiece,
            quantite_totale_piece: details.stockFinalPiece,
            motif,
            commentaire,
            details_mouvement: JSON.stringify(details),
          }
        })
      } else if (typeMouvement == 4) {
        quantite_carton = details.stockFinalCarton
        quantite_piece = details.stockFinalPiece

        nouveauMouvement = await tx.mouvement_stock.create({
          data: {
            type: 'entree',
            mouvement: 4,
            stock_id: nouveauStock.id,
            piece_id: item,
            service_origine: null,
            service_destination: itemService,
            origine,
            model_id: itemModel,
            stock_initial: 0,
            quantite: details.quantiteMouvementCarton,
            stock_final: details.stockFinalCarton,
            quantite_totale_piece: details.stockFinalPiece,
            motif,
            commentaire,
            details_mouvement: JSON.stringify(details),
          }
        })

        const cartonsData = Array.from({ length: quantite_carton }, (_, i) => ({
          numero_carton: i + 1,
          stock_id: nouveauStock.id,
          piece_id: item,
          model_id: itemModel,
          service_id: itemService,
          quantite_piece_carton: details.quantitePieceCarton,
          quantite_totale_piece: details.quantitePieceCarton,
        }));

        await tx.stock_carton.createMany({
          data: cartonsData,
        });

      } else if (typeMouvement == 1) {
        quantite_lot = Number(details.stockFinalLot)
        quantite_carton = Number(details.stockFinalCarton)
        quantite_piece = Number(details.stockFinalPiece)

        nouveauMouvement = await tx.mouvement_stock.create({
          data: {
            type: 'entree',
            mouvement: 1,
            stock_id: nouveauStock.id,
            piece_id: item,
            service_origine: null,
            service_destination: itemService,
            origine,
            model_id: itemModel,
            stock_initial: 0,
            quantite: details.quantiteMouvementLot,
            stock_final: details.stockFinalLot,
            quantite_totale_piece: details.stockFinalPiece,
            motif,
            commentaire,
            details_mouvement: JSON.stringify(details),
          }
        })

        // 1. Create lots in bulk
        const lotsData = Array.from({ length: quantite_lot }, (_, i) => ({
          numero_lot: i + 1,
          stock_id: nouveauStock.id,
          quantite_carton_lot: details.quantiteCartonLot,
          quantite_carton: details.quantiteCartonLot,
          quantite_piece: details.quantitePieceLot,
          piece_id: item,
          model_id: itemModel,
          service_id: itemService,
        }));

        await tx.stock_lot.createMany({ data: lotsData });

        // 2. Fetch created lots
        const createdLots = await tx.stock_lot.findMany({
          where: { stock_id: nouveauStock.id },
          orderBy: { numero_lot: 'asc' }, // important!
        });

        // 3. Build cartons data
        const cartonsData = [];

        for (const lot of createdLots) {
          for (let i = 0; i < details.quantiteCartonLot; i++) {
            cartonsData.push({
              numero_carton: i + 1,
              stock_id: nouveauStock.id,
              lot_id: lot.id,
              numero_lot: lot.numero_lot,
              piece_id: item,
              service_id: itemService,
              model_id: itemModel,
              quantite_piece_carton: details.quantitePieceCarton,
              quantite_totale_piece: details.quantitePieceCarton,
            });
          }
        }

        // 4. Bulk insert cartons
        await tx.stock_carton.createMany({ data: cartonsData });
      }

      await tx.stocks.update({
        where: {
          id: nouveauStock.id,
        },
        data: {
          quantite_lot,
          quantite_carton,
          quantite_piece,
        }
      })

      return {
        nouveauStock,
        nouveauMouvement,
      }
    })

    res.status(201).json({
      message: "Nouveau stock enregistré avec succès",
      data: creationStock,
    });
  } catch (error) {
    console.log("Erreur lors de la création :", error);
    res.status(500).json({ message: "Erreur interne", error });
  }
}

const getAllStocks = async (req, res) => {
  try {
    const stocks = await prisma.stocks.findMany({
      orderBy: { id: 'desc' },
      include: {
        items: true,
        model_piece: true,
        services: true,
        stockOwner: true,
      }
    });

    res.status(200).json(stocks);
  } catch (error) {
    res.status(500).json({ message: "Erreur lors de la récupération des stocks", error });
  }
}

const getOneStock = async (req, res) => {
  const { id } = req.params;
  try {
    const stock = await prisma.stocks.findUnique({
      where: {
        id: parseInt(id)
      },
      include: {
        items: true,
        model_piece: true,
        services: true,
        stockOwner: true,
      }
    });

    if (!stock) {
      return res.status(404).json({ message: "Stock introuvable !" })
    }

    return res.status(200).json(stock)
  } catch (error) {
    res.status(500).json({ message: "Erreur serveur", error })
    console.log(error)
  }
}

const getPiece = async (req, res) => {
  const { id } = req.params;
  try {
    const piece = await prisma.items.findUnique({
      where: {
        id_piece: parseInt(id)
      }
    })

    if (!piece) {
      return res.status(404).json({ message: "Pièce introuvable !" })
    }

    return res.status(200).json(piece)
  } catch (error) {
    res.status(500).json({ message: "Erreur serveur", error })
    console.log(error)
  }
}

const modifyPiece = async (req, res) => {
  try {
    const {
      id
    } = req.params
    const {
      nomPiece,
      type,
      itemModels,
      itemServices,
      code_piece,
      user_id,
    } = req.body

    const piece = await prisma.items.findUnique({
      where: {
        id_piece: parseInt(id)
      }
    })

    if (!piece) {
      return res.status(404).json({ message: "Pièce introuvable !" })
    }

    const dataToUpdate = {
      nom_piece: nomPiece,
      type: type,
      code_piece,
      user_id: parseInt(user_id),
    }

    await prisma.items_models.deleteMany({
      where: {
        item_id: parseInt(id)
      }
    })

    await prisma.items_services.deleteMany({
      where: {
        item_id: parseInt(id)
      }
    })

    if (itemModels && Array.isArray(itemModels)) {
      await prisma.items_models.createMany({
        data: itemModels.map(modelId => ({
          item_id: piece.id_piece,
          model_id: modelId,
        })),
      });
    }

    if (itemServices && Array.isArray(itemServices)) {
      await prisma.items_services.createMany({
        data: itemServices.map(serviceId => ({
          item_id: piece.id_piece,
          service_id: serviceId,
        })),
      });
    }

    const pieceUpdated = await prisma.items.update({
      where: {
        id_piece: parseInt(id),
      },
      data: dataToUpdate,
    })

    return res.status(200).json(pieceUpdated)

  } catch (error) {
    console.log(error);
    return res.status(500).json({ message: "Erreur lors de la mise à jour", error });
  }
}

const getAllModels = async (req, res) => {
  try {
    const models = await prisma.model_piece.findMany({
      orderBy: { id_model: 'asc' },
    });

    res.status(200).json(models);
  } catch (error) {
    res.status(500).json({ message: "Erreur lors de la récupération des models", error });
  }
}

const getItemModels = async (req, res) => {
  try {
    const { id } = req.params;

    const items_models = await prisma.items_models.findMany({
      where: { item_id: parseInt(id) },
      include: { model_piece: true }
    })

    res.status(200).json({
      model_piece: items_models.map(m => m.model_piece)
    });
  } catch (error) {
    res.status(500).json({ message: "Erreur serveur", error });
  }
}

const getItemServices = async (req, res) => {
  try {
    const { id } = req.params;

    const items_services = await prisma.items_services.findMany({
      where: { item_id: parseInt(id) },
      include: { services: true }
    })

    res.status(200).json({
      services: items_services.map(s => s.services)
    });
  } catch (error) {
    res.status(500).json({ message: "Erreur serveur", error });
  }
}

// Attribuer une quantité à un stock choisi en fonction de l'ID du stock.
const setStockPiece = async (req, res) => {

  const {
    item_id,
    model_id,
    service_id,
  } = req.params

  const {
    stockInitial,
    quantiteMouvement,
    stockFinal,
    motif,
    commentaire,
    isEntree,
    userId,
  } = req.body;

  try {

    let utilisateur = null;
    if (userId != null) {
      utilisateur = await prisma.users.findUnique({
        where: {
          id_user: parseInt(userId)
        }
      })
      if (!utilisateur) {
        return res.status(404).json({ message: "Utilisateur non trouvé" });
      }
    }

    const piece = await prisma.items.findUnique({
      where: {
        id_piece: parseInt(item_id)
      }
    })
    if (!piece) {
      return res.status(404).json({ message: "Pièce non trouvée" });
    }

    const type = isEntree ? 'entree' : 'sortie'

    const initial = Number(stockInitial)
    const stock = Number(quantiteMouvement)
    const final = Number(stockFinal)

    const mouvement = await prisma.mouvement_stock.create({
      data: {
        type,
        mouvement: 5,
        piece_id: parseInt(item_id),
        service_origine: isEntree ? null : parseInt(service_id),
        service_destination: isEntree ? parseInt(service_id) : null,
        model_id: parseInt(model_id),
        stock_initial: initial,
        quantite: stock,
        stock_final: final,
        quantite_totale_piece: final,
        motif,
        commentaire,
      }
    })

    const quantite = await prisma.stock_piece.findFirst({
      where: {
        piece_id: parseInt(item_id),
        model_id: parseInt(model_id),
        service_id: parseInt(service_id),
      }
    })

    if (!quantite) {
      const newQuantite = await prisma.stock_piece.create({
        data: {
          piece_id: parseInt(item_id),
          model_id: parseInt(model_id),
          service_id: parseInt(service_id),
          quantite: parseInt(stockFinal),
        }
      })
      return res.status(201).json(newQuantite, mouvement)
    }

    const dataToUpdate = {
      quantite: parseInt(stockFinal)
    }

    const updated_quantite = await prisma.stock_piece.update({
      where: {
        id: quantite.id,
        piece_id: parseInt(item_id),
        model_id: parseInt(model_id),
        service_id: parseInt(service_id),
      },
      data: dataToUpdate
    })

    return res.status(200).json(updated_quantite, mouvement);
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Erreur lors de la mise à jour", error });
  }
}

// Attribuer une quantité à un stock de cartons choisi en fonction de l'ID du stock.
const setStockCarton = async (req, res) => {

  const {
    item_id,
    model_id,
    service_id,
  } = req.params

  const {
    stockInitialCarton,
    quantiteMouvementCarton,
    stockFinalCarton,
    details,
    motif,
    commentaire,
    isEntree,
    userId
  } = req.body;

  try {

    const detailsCartons = typeof details === "string" ? JSON.parse(details) : details;

    let utilisateur = null;
    if (userId != null) {
      utilisateur = await prisma.users.findUnique({
        where: {
          id_user: parseInt(userId)
        }
      })
      if (!utilisateur) {
        return res.status(404).json({ message: "Utilisateur non trouvé" });
      }
    }

    const piece = await prisma.items.findUnique({
      where: {
        id_piece: parseInt(item_id)
      }
    })
    if (!piece) {
      return res.status(404).json({ message: "Pièce non trouvée" });
    }

    const type = isEntree ? 'entree' : 'sortie'

    const initialCarton = Number(stockInitialCarton)
    const stockCarton = Number(quantiteMouvementCarton)
    const finalCarton = Number(stockFinalCarton)
    const finalPiece = Number(detailsCartons.stockFinalPiece)

    const mouvement = await prisma.mouvement_stock.create({
      data: {
        type,
        mouvement: 4,
        piece_id: parseInt(item_id),
        service_origine: isEntree ? null : parseInt(service_id),
        service_destination: isEntree ? parseInt(service_id) : null,
        model_id: parseInt(model_id),
        stock_initial: initialCarton,
        quantite: stockCarton,
        stock_final: finalCarton,
        quantite_totale_piece: finalPiece,
        motif,
        commentaire,
        details_mouvement: JSON.stringify(detailsCartons),
      }
    })

    const quantite = await prisma.stock_piece.findFirst({
      where: {
        piece_id: parseInt(item_id),
        model_id: parseInt(model_id),
        service_id: parseInt(service_id),
      }
    })

    let updatedQuantite = null

    if (quantite) {
      const dataToUpdate = {
        quantite: parseInt(detailsCartons.stockFinalPiece)
      }
      updatedQuantite = await prisma.stock_piece.update({
        where: {
          id: quantite.id,
          piece_id: parseInt(item_id),
          model_id: parseInt(model_id),
          service_id: parseInt(service_id),
        },
        data: dataToUpdate
      })
    } else {
      updatedQuantite = await prisma.stock_piece.create({
        data: {
          piece_id: parseInt(item_id),
          model_id: parseInt(model_id),
          service_id: parseInt(service_id),
          quantite: parseInt(detailsCartons.stockFinalPiece),
        }
      })
    }

    if (isEntree) {
      const listCarton = await prisma.stock_carton.findMany({
        where: {
          piece_id: parseInt(item_id),
          model_id: parseInt(model_id),
          service_id: parseInt(service_id),
          lot_id: null,
        },
        orderBy: { numero_carton: "asc" },
      });

      const lastCarton = listCarton[listCarton.length - 1];
      const lastId = lastCarton ? lastCarton.numero_carton : 0;
      const piecesPerCarton = Number(detailsCartons.quantitePieceCarton);

      for (let i = 0; i < stockCarton; i++) {
        await prisma.stock_carton.create({
          data: {
            numero_carton: lastId + i + 1,
            piece_id: parseInt(item_id),
            model_id: parseInt(model_id),
            service_id: parseInt(service_id),
            quantite_piece_carton: piecesPerCarton,
            quantite_totale_piece: piecesPerCarton,
          },
        });
      }
    } else {
      const listCarton = detailsCartons.listeCartons
      for (let id of listCarton) {
        await prisma.stock_carton.update({
          where: {
            id: parseInt(id)
          },
          data: {
            is_deleted: true,
          }
        })
      }
    }

    return res.status(200).json(updatedQuantite, mouvement);
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Erreur lors de la mise à jour", error });
  }
}

// Attribuer une quantité à un carton choisi en fonction de l'ID du carton.
const setStockPieceCarton = async (req, res) => {
  const {
    item_id,
    model_id,
    service_id,
  } = req.params

  const {
    stockInitialPieceCarton,
    quantiteMouvementPieceCarton,
    stockFinalPieceCarton,
    details,
    motif,
    commentaire,
    isEntree,
    userId
  } = req.body;

  try {

    const detailsPieceCarton = typeof details === "string" ? JSON.parse(details) : details;

    let utilisateur = null;
    if (userId != null) {
      utilisateur = await prisma.users.findUnique({
        where: {
          id_user: parseInt(userId)
        }
      })
      if (!utilisateur) {
        return res.status(404).json({ message: "Utilisateur non trouvé" });
      }
    }

    const piece = await prisma.items.findUnique({
      where: {
        id_piece: parseInt(item_id)
      }
    })
    if (!piece) {
      return res.status(404).json({ message: "Pièce non trouvée" });
    }

    const type = isEntree ? 'entree' : 'sortie'

    const initialPieceCarton = Number(stockInitialPieceCarton)
    const stockPieceCarton = Number(quantiteMouvementPieceCarton)
    const finalPieceCarton = Number(stockFinalPieceCarton)
    const finalPiece = Number(detailsPieceCarton.stockFinalPiece)

    const mouvement = await prisma.mouvement_stock.create({
      data: {
        type,
        mouvement: 3,
        piece_id: parseInt(item_id),
        service_origine: isEntree ? null : parseInt(service_id),
        service_destination: isEntree ? parseInt(service_id) : null,
        model_id: parseInt(model_id),
        stock_initial: initialPieceCarton,
        quantite: stockPieceCarton,
        stock_final: finalPieceCarton,
        quantite_totale_piece: finalPiece,
        motif,
        commentaire,
        details_mouvement: JSON.stringify(detailsPieceCarton),
      }
    })

    const quantite = await prisma.stock_piece.findFirst({
      where: {
        piece_id: parseInt(item_id),
        model_id: parseInt(model_id),
        service_id: parseInt(service_id),
      }
    })

    let updatedQuantite = null

    if (quantite) {
      const dataToUpdate = {
        quantite: parseInt(detailsPieceCarton.stockFinalPiece)
      }

      updatedQuantite = await prisma.stock_piece.update({
        where: {
          id: quantite.id,
          piece_id: parseInt(item_id),
          model_id: parseInt(model_id),
          service_id: parseInt(service_id),
        },
        data: dataToUpdate
      })
    } else {
      updatedQuantite = await prisma.stock_piece.create({
        data: {
          piece_id: parseInt(item_id),
          model_id: parseInt(model_id),
          service_id: parseInt(service_id),
          quantite: parseInt(detailsPieceCarton.stockFinalPiece),
        }
      })
    }

    let updatedCarton = await prisma.stock_carton.update({
      where: { id: parseInt(detailsPieceCarton.selectedCarton) },
      data: {
        quantite_totale_piece: finalPieceCarton
      },
    })

    if (finalPieceCarton == 0) {
      updatedCarton = await prisma.stock_carton.update({
        where: { id: parseInt(detailsPieceCarton.selectedCarton) },
        data: {
          quantite_totale_piece: finalPieceCarton,
          is_deleted: true,
        },
      })
    }

    if (detailsPieceCarton.selectedLot) {
      const finalPieceLot = Number(detailsPieceCarton.stockFinalPieceLot)
      let updatedLot = await prisma.stock_lot.update({
        where: {
          id: parseInt(detailsPieceCarton.selectedLot)
        },
        data: {
          quantite_piece: finalPieceLot,
        }
      })
      if (finalPieceCarton == 0) {
        updatedLot = await prisma.stock_lot.update({
          where: {
            id: parseInt(detailsPieceCarton.selectedLot)
          },
          data: {
            quantite_piece: finalPieceLot,
            quantite_carton: updatedLot.quantite_carton - 1,
          },
        })
      }
      if (updatedLot.quantite_carton == 0) {
        updatedLot = await prisma.stock_lot.update({
          where: {
            id: parseInt(detailsPieceCarton.selectedLot)
          },
          data: {
            quantite_piece: finalPieceLot,
            quantite_carton: 0,
            is_deleted: true
          }
        })
      }
    }

    return res.status(200).json(updatedQuantite, mouvement, updatedCarton);
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Erreur lors de la mise à jour", error });
  }
}

// Attribuer une quantité de carton à un lot choisi en fonction de l'ID du lot.
const setStockCartonLot = async (req, res) => {

  const {
    item_id,
    model_id,
    service_id,
  } = req.params

  const {
    stockInitialCartonLot,
    quantiteMouvementCartonLot,
    stockFinalCartonLot,
    details,
    motif,
    commentaire,
    isEntree,
    userId
  } = req.body;

  try {

    const detailsCartonsLot = typeof details === "string" ? JSON.parse(details) : details;

    let utilisateur = null;
    if (userId != null) {
      utilisateur = await prisma.users.findUnique({
        where: {
          id_user: parseInt(userId)
        }
      })
      if (!utilisateur) {
        return res.status(404).json({ message: "Utilisateur non trouvé" });
      }
    }

    const piece = await prisma.items.findUnique({
      where: {
        id_piece: parseInt(item_id)
      }
    })
    if (!piece) {
      return res.status(404).json({ message: "Pièce non trouvée" });
    }

    const type = isEntree ? 'entree' : 'sortie'

    const initialCartonLot = Number(stockInitialCartonLot)
    const stockCartonLot = Number(quantiteMouvementCartonLot)
    const finalCartonLot = Number(stockFinalCartonLot)
    const finalPiece = Number(detailsCartonsLot.stockFinalPiece)
    const finalPieceLot = Number(detailsCartonsLot.stockFinalPieceLot)

    const mouvement = await prisma.mouvement_stock.create({
      data: {
        type,
        mouvement: 2,
        piece_id: parseInt(item_id),
        service_origine: isEntree ? null : parseInt(service_id),
        service_destination: isEntree ? parseInt(service_id) : null,
        model_id: parseInt(model_id),
        stock_initial: initialCartonLot,
        quantite: stockCartonLot,
        stock_final: finalCartonLot,
        quantite_totale_piece: finalPiece,
        motif,
        commentaire,
        details_mouvement: JSON.stringify(detailsCartonsLot),
      }
    })

    const quantite = await prisma.stock_piece.findFirst({
      where: {
        piece_id: parseInt(item_id),
        model_id: parseInt(model_id),
        service_id: parseInt(service_id),
      }
    })

    let updatedQuantite = null

    if (quantite) {
      const dataToUpdate = {
        quantite: parseInt(detailsCartonsLot.stockFinalPiece)
      }
      updatedQuantite = await prisma.stock_piece.update({
        where: {
          id: quantite.id,
          piece_id: parseInt(item_id),
          model_id: parseInt(model_id),
          service_id: parseInt(service_id),
        },
        data: dataToUpdate
      })
    } else {
      updatedQuantite = await prisma.stock_piece.create({
        data: {
          piece_id: parseInt(item_id),
          model_id: parseInt(model_id),
          service_id: parseInt(service_id),
          quantite: parseInt(detailsCartonsLot.stockFinalPiece),
        }
      })
    }

    let updatedLot = await prisma.stock_lot.update({
      where: {
        id: parseInt(detailsCartonsLot.selectedLot),
      },
      data: {
        quantite_carton: finalCartonLot,
        quantite_piece: finalPieceLot,
      },
    })

    if (finalCartonLot == 0) {
      updatedLot = await prisma.stock_lot.update({
        where: {
          id: parseInt(detailsCartonsLot.selectedLot),
        },
        data: {
          quantite_carton: finalCartonLot,
          quantite_piece: finalPieceLot,
          is_deleted: true,
        },
      })
    }

    if (isEntree) {
      const listCartonLot = await prisma.stock_carton.findMany({
        where: {
          piece_id: parseInt(item_id),
          lot_id: parseInt(detailsCartonsLot.selectedLot),
          model_id: parseInt(model_id),
          service_id: parseInt(service_id),
        },
        orderBy: { numero_carton: "asc" },
      });

      const lastCarton = listCartonLot[listCartonLot.length - 1];
      const lastId = lastCarton ? lastCarton.numero_carton : 0;
      const piecesPerCarton = Number(detailsCartonsLot.quantitePieceCarton);

      for (let i = 0; i < stockCartonLot; i++) {
        await prisma.stock_carton.create({
          data: {
            numero_carton: lastId + i + 1,
            lot_id: updatedLot.id,
            numero_lot: updatedLot.numero_lot,
            piece_id: parseInt(item_id),
            model_id: parseInt(model_id),
            service_id: parseInt(service_id),
            quantite_piece_carton: piecesPerCarton,
            quantite_totale_piece: piecesPerCarton,
          },
        });
      }
    } else {
      const listCartonLot = detailsCartonsLot.listeCartons
      for (let id of listCartonLot) {
        await prisma.stock_carton.update({
          where: {
            id: parseInt(id),
            lot_id: updatedLot.id,
            model_id: parseInt(model_id),
            service_id: parseInt(service_id),
          },
          data: {
            is_deleted: true,
          }
        })
      }
    }

    return res.status(200).json(updatedQuantite, mouvement);
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Erreur lors de la mise à jour", error });
  }
}

// Attribuer une quantité de lots à un stock en fonction de l'ID du stock.
const setStockLot = async (req, res) => {

  const {
    item_id,
    model_id,
    service_id,
  } = req.params

  const {
    stockInitialLot,
    quantiteMouvementLot,
    stockFinalLot,
    details,
    motif,
    commentaire,
    isEntree,
    userId
  } = req.body;

  try {

    const detailsLots = typeof details === "string" ? JSON.parse(details) : details;

    let utilisateur = null;
    if (userId != null) {
      utilisateur = await prisma.users.findUnique({
        where: {
          id_user: parseInt(userId)
        }
      })
      if (!utilisateur) {
        return res.status(404).json({ message: "Utilisateur non trouvé" });
      }
    }

    const piece = await prisma.items.findUnique({
      where: {
        id_piece: parseInt(item_id)
      }
    })
    if (!piece) {
      return res.status(404).json({ message: "Pièce non trouvée" });
    }

    const type = isEntree ? 'entree' : 'sortie'

    const initialLot = Number(stockInitialLot)
    const stockLot = Number(quantiteMouvementLot)
    const finalLot = Number(stockFinalLot)
    const finalPiece = Number(detailsLots.stockFinalPiece)

    const mouvement = await prisma.mouvement_stock.create({
      data: {
        type,
        mouvement: 1,
        piece_id: parseInt(item_id),
        service_origine: isEntree ? null : parseInt(service_id),
        service_destination: isEntree ? parseInt(service_id) : null,
        model_id: parseInt(model_id),
        stock_initial: initialLot,
        quantite: stockLot,
        stock_final: finalLot,
        quantite_totale_piece: finalPiece,
        motif,
        commentaire,
        details_mouvement: JSON.stringify(detailsLots),
      }
    })

    const quantite = await prisma.stock_piece.findFirst({
      where: {
        piece_id: parseInt(item_id),
        model_id: parseInt(model_id),
        service_id: parseInt(service_id),
      }
    })

    let updatedQuantite = null
    if (quantite) {
      const dataToUpdate = {
        quantite: parseInt(detailsLots.stockFinalPiece)
      }
      updatedQuantite = await prisma.stock_piece.update({
        where: {
          id: quantite.id,
          piece_id: parseInt(item_id),
          model_id: parseInt(model_id),
          service_id: parseInt(service_id),
        },
        data: dataToUpdate
      })
    } else {
      updatedQuantite = await prisma.stock_piece.create({
        data: {
          piece_id: parseInt(item_id),
          model_id: parseInt(model_id),
          service_id: parseInt(service_id),
          quantite: parseInt(detailsLots.stockFinalPiece),
        }
      })
    }

    if (isEntree) {
      const listLot = await prisma.stock_lot.findMany({
        where: {
          piece_id: parseInt(item_id),
          model_id: parseInt(model_id),
          service_id: parseInt(service_id),
        },
        orderBy: { numero_lot: "asc" },
      });

      const lastLot = listLot[listLot.length - 1];
      const lastId = lastLot ? lastLot.numero_lot : 0;
      const cartonPerLot = Number(detailsLots.quantiteCartonLot);
      const piecesPerCarton = Number(detailsLots.quantitePieceCarton);
      const piecesPerLot = Number(detailsLots.quantiteCartonLot * detailsLots.quantitePieceCarton)
      for (let i = 0; i < stockLot; i++) {
        const newLot = await prisma.stock_lot.create({
          data: {
            numero_lot: lastId + i + 1,
            quantite_carton_lot: cartonPerLot,
            quantite_carton: cartonPerLot,
            quantite_piece: piecesPerLot,
            piece_id: parseInt(item_id),
            model_id: parseInt(model_id),
            service_id: parseInt(service_id),
          },
        });
        for (let i = 0; i < cartonPerLot; i++) {
          await prisma.stock_carton.create({
            data: {
              numero_carton: i + 1,
              lot_id: newLot.id,
              numero_lot: newLot.numero_lot,
              piece_id: parseInt(item_id),
              service_id: parseInt(service_id),
              model_id: parseInt(model_id),
              quantite_piece_carton: piecesPerCarton,
              quantite_totale_piece: piecesPerCarton,
            }
          })
        }
      }
    } else {
      const listLot = detailsLots.listeLots
      for (let id of listLot) {
        await prisma.stock_lot.update({
          where: {
            id: parseInt(id)
          },
          data: {
            is_deleted: true,
          }
        })
        await prisma.stock_carton.updateMany({
          where: {
            lot_id: parseInt(id)
          },
          data: {
            is_deleted: true,
          }
        })
      }
    }

    return res.status(200).json(updatedQuantite, mouvement);
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Erreur lors de la mise à jour", error });
  }
}

// // Création d'un stock à partir d'un fichier Excel de numéros de série (colonnes SERIAL NUMBER, LOT et CARTON optionnelles).
// - Un SN déjà actif en stock bloque l'import ; un SN sorti auparavant (is_deleted) est réutilisé et rattaché au nouveau stock
//   (serial_number est unique en base : on ne peut pas le recréer).
// - Le créateur devient owner du stock (stocks.owner + stock_owners).
// - Terminaux : parc TPE (statut 1) et historique écrits dans une transaction, après la création du stock.
const OPTIONS_TRANSACTION_IMPORT = { maxWait: 10000, timeout: 60000 }

const setStockSn = async (req, res) => {
  const {
    item_id,
    model_id,
    service_id,
    origine,
    codeStock,
    motif,
    userId,
    commentaire,
  } = req.body;

  const file = req.file;

  try {
    const utilisateur = await prisma.users.findUnique({
      where: { id_user: parseInt(userId) }
    });
    if (!utilisateur) {
      return res.status(404).json({ message: "Utilisateur non trouvé" });
    }

    const piece = await prisma.items.findUnique({
      where: { id_piece: parseInt(item_id) }
    });
    if (!piece) {
      return res.status(404).json({ message: "Pièce non trouvée" });
    }
    const estTerminal = String(piece.type || '').toUpperCase() == "TERMINAL"

    if (!parseInt(model_id) || !parseInt(service_id)) {
      return res.status(400).json({ message: "Vous devez choisir le modèle et le service du stock." });
    }

    const erreurCode = await verifierCodeStock(codeStock)
    if (erreurCode) {
      return res.status(400).json({ message: erreurCode });
    }
    const code = String(codeStock).trim()

    if (!file) {
      console.error("No file uploaded");
      return res.status(400).json({ message: "Excel file is required" });
    }

    /* =========================
       1️⃣ LOAD EXCEL
    ========================== */
    const workbook = new ExcelJS.Workbook();
    await workbook.xlsx.load(file.buffer);
    const worksheet = workbook.worksheets[0];

    if (!worksheet) {
      console.error("No worksheet found in Excel file");
      return res.status(400).json({ message: "Invalid Excel file" });
    }

    /* =========================
       2️⃣ READ HEADERS
    ========================== */
    const headers = {};
    worksheet.getRow(1).eachCell((cell, col) => {
      headers[String(cell.value).trim().toUpperCase()] = col;
    });

    if (!headers["SERIAL NUMBER"]) {
      console.error("Missing SERIAL NUMBER column in Excel file")
      return res.status(400).json({
        message: "Missing required column: SERIAL NUMBER",
      });
    }

    const hasLot = !!headers["LOT"];
    const hasCarton = !!headers["CARTON"];

    /* =========================
       3️⃣ PARSE ROWS → HIERARCHY
    ========================== */
    const serialSet = new Set();
    const doublons = [];
    const hierarchy = {}; // lot → carton → [sn]

    worksheet.eachRow((row, rowNumber) => {
      if (rowNumber === 1) return;

      const sn = normalize(row.getCell(headers["SERIAL NUMBER"]).value);
      if (!sn) return;

      if (serialSet.has(sn)) {
        doublons.push(`${sn} (ligne ${rowNumber})`);
        return;
      }

      serialSet.add(sn);

      const lot = hasLot
        ? extractNumber(row.getCell(headers["LOT"]).value)
        : null;

      const carton = hasCarton
        ? extractNumber(row.getCell(headers["CARTON"]).value)
        : null;

      const lotKey = lot ?? "NO_LOT";
      const cartonKey = carton ?? "NO_CARTON";

      if (!hierarchy[lotKey]) hierarchy[lotKey] = {};
      if (!hierarchy[lotKey][cartonKey]) hierarchy[lotKey][cartonKey] = [];

      hierarchy[lotKey][cartonKey].push(sn);
    });

    if (doublons.length > 0) {
      return res.status(400).json({ message: `SN en double dans le fichier : ${doublons.join(", ")}` });
    }

    if (serialSet.size === 0) {
      console.error("No serial numbers found in Excel file");
      return res.status(400).json({ message: "Excel file is empty" });
    }

    /* =========================
       4️⃣ CHECK EXISTING SNs
    ========================== */
    const existants = await prisma.serial_numbers.findMany({
      where: { serial_number: { in: [...serialSet] } },
      select: { id: true, serial_number: true, is_deleted: true },
    });

    const actifs = existants.filter((e) => !e.is_deleted)
    if (actifs.length > 0) {
      const message = `Serial numbers already exist: ${actifs.map(e => e.serial_number).join(", ")}`
      console.error(message);
      return res.status(400).json({ message });
    }
    // SN sortis auparavant : réutilisés (rattachés au nouveau stock)
    const sortisParSerial = new Map(existants.map((e) => [e.serial_number, e.id]))

    const serials = [...serialSet];

    // Terminaux : modèle obligatoire, existant, et identique à celui déjà enregistré au parc (vérifié AVANT la création du stock)
    if (estTerminal) {
      const itemsModele = serials.map((serial) => ({ serial, modelId: model_id }))
      const erreurModele = await verifierModelesExistants(prisma, itemsModele, { obligatoire: true })
      if (erreurModele) {
        console.error(erreurModele)
        return res.status(400).json({ message: erreurModele });
      }
      const conflits = trouverConflitsModele(itemsModele, await getTpesParc(prisma, serials))
      if (conflits.length > 0) {
        const message = `Le modèle choisi ne correspond pas au modèle enregistré au parc pour : ${conflits.map((c) => `${c.serial} (${String(c.nomModeleParc || c.modeleParc).toUpperCase()})`).join(", ")}`
        console.error(message)
        return res.status(400).json({ message });
      }
    }

    const idPiece = piece.id_piece
    const idModel = parseInt(model_id)
    const idService = parseInt(service_id)
    const dateAction = new Date();

    const creationStock = await prisma.$transaction(async (tx) => {
      /* =========================
         5️⃣ CREATE STOCK + OWNER
      ========================== */
      const stock = await tx.stocks.create({
        data: {
          code_stock: code,
          piece_id: idPiece,
          model_id: idModel,
          service_id: idService,
          quantite_lot: Object.keys(hierarchy).filter(k => k !== "NO_LOT").length,
          quantite_carton: Object.values(hierarchy)
            .reduce((acc, l) => acc + Object.keys(l).length, 0),
          quantite_piece: serialSet.size,
          created_at: dateAction,
          created_by: utilisateur.id_user,
          last_update: dateAction,
          updated_by: utilisateur.id_user,
          owner: utilisateur.id_user,
        },
      });

      await tx.stock_owners.create({
        data: {
          user_id: utilisateur.id_user,
          stock_id: stock.id,
          type: 'owner',
        }
      })

      /* =========================
         6️⃣ MOUVEMENT STOCK
      ========================== */
      const mouvementDetails = {
        typeMouvement: 6,
        lots: Object.entries(hierarchy).map(([lotKey, cartons]) => ({
          lot: lotKey === "NO_LOT" ? null : Number(lotKey),
          cartons: Object.entries(cartons).map(([cartonKey, sns]) => ({
            carton: cartonKey === "NO_CARTON" ? null : Number(cartonKey),
            serial_numbers: sns
          }))
        })),
        stockFinalLot: stock.quantite_lot,
        stockFinalCarton: stock.quantite_carton,
        stockFinalPiece: serialSet.size,
        snReutilises: [...sortisParSerial.keys()],
      };

      await tx.mouvement_stock.create({
        data: {
          type: "entree",
          mouvement: 6,
          created_at: dateAction,
          stock_id: stock.id,
          piece_id: idPiece,
          origine,
          service_destination: idService,
          model_id: idModel,
          stock_initial: 0,
          quantite: serialSet.size,
          stock_final: serialSet.size,
          quantite_totale_piece: serialSet.size,
          motif,
          commentaire,
          details_mouvement: JSON.stringify(mouvementDetails),
          created_by: utilisateur.id_user,
        },
      });

      /* =========================
         7️⃣ LOTS
      ========================== */
      const lotsData = [];
      const cartonsData = [];

      for (const [lotKey, cartons] of Object.entries(hierarchy)) {
        const numeroLot = lotKey === "NO_LOT" ? null : parseInt(lotKey);

        lotsData.push({
          numero_lot: numeroLot,
          stock_id: stock.id,
          piece_id: idPiece,
          service_id: idService,
          model_id: idModel,
          quantite_carton: Object.keys(cartons).length,
          quantite_piece: Object.values(cartons)
            .reduce((a, sns) => a + sns.length, 0),
        });

        for (const [cartonKey, sns] of Object.entries(cartons)) {
          cartonsData.push({
            numero_lot: numeroLot,
            numero_carton: cartonKey === "NO_CARTON" ? null : parseInt(cartonKey),
            sns,
          });
        }
      }

      await tx.stock_lot.createMany({ data: lotsData });

      const insertedLots = await tx.stock_lot.findMany({
        where: { stock_id: stock.id },
        select: { id: true, numero_lot: true },
      });

      // Un seul lot « sans numéro » possible (clé NO_LOT)
      const lotMap = new Map(insertedLots.map((lot) => [lot.numero_lot, lot.id]));

      /* =========================
         8️⃣ CARTONS
      ========================== */
      const cartonsFinal = cartonsData.map((c) => ({
        numero_carton: c.numero_carton,
        lot_id: lotMap.get(c.numero_lot),
        numero_lot: c.numero_lot,
        stock_id: stock.id,
        piece_id: idPiece,
        service_id: idService,
        model_id: idModel,
        quantite_piece_carton: c.sns.length,
        quantite_totale_piece: c.sns.length,
      }));

      await tx.stock_carton.createMany({ data: cartonsFinal });

      const insertedCartons = await tx.stock_carton.findMany({
        where: { stock_id: stock.id },
        select: { id: true, numero_carton: true, lot_id: true },
      });

      // Dans un lot, un seul carton « sans numéro » possible (clé NO_CARTON)
      const cartonMap = new Map(insertedCartons.map((carton) => [`${carton.lot_id}-${carton.numero_carton ?? "NULL"}`, carton.id]));

      /* =========================
         9️⃣ SERIAL NUMBERS (création ou réutilisation)
      ========================== */
      const nouveaux = [];
      for (const c of cartonsData) {
        const lotId = lotMap.get(c.numero_lot);
        const cartonId = cartonMap.get(`${lotId}-${c.numero_carton ?? "NULL"}`);
        const reutilises = [];

        c.sns.forEach((sn) => {
          if (sortisParSerial.has(sn)) {
            reutilises.push(sortisParSerial.get(sn));
          } else {
            nouveaux.push({
              serial_number: sn,
              stock_id: stock.id,
              lot_id: lotId,
              carton_id: cartonId,
              item_id: idPiece,
              service_id: idService,
              model_id: idModel,
              created_at: dateAction,
            });
          }
        });

        if (reutilises.length > 0) {
          await tx.serial_numbers.updateMany({
            where: { id: { in: reutilises } },
            data: {
              stock_id: stock.id,
              lot_id: lotId,
              carton_id: cartonId,
              item_id: idPiece,
              service_id: idService,
              model_id: idModel,
              is_deleted: false,
            },
          });
        }
      }

      if (nouveaux.length > 0) {
        await tx.serial_numbers.createMany({ data: nouveaux });
      }

      return {
        stock,
        mouvementDetails,
      };
    }, OPTIONS_TRANSACTION_IMPORT);

    let allTpes = null
    if (estTerminal) {
      allTpes = await prisma.$transaction(async (tx) => {
        // 1. Créer les TPE manquants avec le modèle du stock, compléter le modèle des TPE existants sans modèle
        await creerTpesEtCompleterModeles(tx, serials.map((serial) => ({ serial, modelId: model_id })), {
          created_by: utilisateur.id_user,
          created_at: dateAction,
          last_modified_at: dateAction,
          statut_id: 1,
        });

        // 2. Update ALL (existing + newly created)
        await tx.parc_tpe.updateMany({
          where: { serial_number: { in: serials } },
          data: {
            updated_by: utilisateur.id_user,
            updated_at: dateAction,
            last_modified_at: dateAction,
            statut_id: 1,
          }
        });

        const tpes = await tx.parc_tpe.findMany({
          where: { serial_number: { in: serials } },
          select: { id: true, serial_number: true }
        });

        // Nouveaux historiques pour chaque TPE mis à jour ou nouvellement créé
        await tx.history_tpe.createMany({
          data: tpes.map(tpe => ({
            id_tpe: tpe.id,
            created_by: utilisateur.id_user,
            created_at: dateAction,
            statut_id: 1,
          }))
        });
        return tpes
      }, OPTIONS_TRANSACTION_IMPORT);
    }

    console.log('Stock SN created successfully')
    return res.status(200).json({
      message: "Stock SN created successfully",
      inserted: serialSet.size,
      reutilises: sortisParSerial.size,
      data: creationStock,
      tpe: allTpes,
    });

  } catch (error) {
    console.error(error);
    return res.status(500).json({
      message: error.message || "Failed to process Excel file",
    });
  }
};

const getAllMouvementStock = async (req, res) => {
  try {
    const mouvement = await prisma.mouvement_stock.findMany({
      orderBy: { id: 'desc' },
      include: {
        items: true,
        model_piece: true,
        type_mouvement_stock: true,
        services_mouvement_stock_service_origineToservices: true,
        services_mouvement_stock_service_destinationToservices: true,
        stocks: {
          select: {
            id: true,
            code_stock: true,
            stockOwner: true,
            created_by: true,
          }
        },
      }
    });

    res.status(200).json(mouvement);
  } catch (error) {
    console.log("Error : ", error)
    res.status(500).json({ message: "Erreur lors de la récupération des entrées sorties", error });
  }
}

const getOneMouvement = async (req, res) => {
  const { id } = req.params;
  try {
    const mouvement = await prisma.mouvement_stock.findUnique({
      where: {
        id: parseInt(id)
      }
    })

    if (!mouvement) {
      return res.status(404).json({ message: "Mouvement introuvable !" })
    }

    return res.status(200).json(mouvement)
  } catch (error) {
    res.status(500).json({ message: "Erreur serveur", error })
    console.log(error)
  }
}

const getOneStockMouvements = async (req, res) => {
  const { id } = req.params;
  try {
    const mouvements = await prisma.mouvement_stock.findMany({
      where: {
        stock_id: parseInt(id)
      },
      include: {
        stocks: true,
        livraison: {
          include: {
            forms: true,
          },
        },
        demandes: {
          include: {
            forms: true,
          },
        },
      },
      orderBy: {
        created_at: 'desc'
      },
    })

    if (!mouvements) {
      return res.status(404).json({ message: "Aucun mouvement éffectué pour stock !" })
    }

    return res.status(200).json(mouvements)
  } catch (error) {
    res.status(500).json({ message: "Erreur serveur", error })
    console.log(error)
  }
}

const getLotPiece = async (req, res) => {
  const { item_id, model_id, service_id } = req.params
  try {
    const lot = await prisma.stock_lot.findMany({
      where: {
        piece_id: parseInt(item_id),
        model_id: parseInt(model_id),
        service_id: parseInt(service_id)
      },
      orderBy: {
        numero_lot: 'asc'
      },
    })
    if (!lot) {
      console.log("Zero lot trouvé")
      return res.status(404).json({ message: "Aucun lot trouvé pour cette pièce !" })
    }

    return res.status(200).json(lot)
  } catch (error) {
    res.status(500).json({ message: "Erreur serveur", error })
    console.log(error)
  }
}

const getCartonLot = async (req, res) => {
  const { id } = req.params
  try {
    const carton = await prisma.stock_carton.findMany({
      where: {
        lot_id: parseInt(id)
      }
    })
    if (!carton) {
      console.log("Zero carton trouvé")
      return res.status(404).json({ message: "Aucun carton trouvé dans ce lot !" })
    }

    return res.status(200).json(carton)
  } catch (error) {
    res.status(500).json({ message: "Erreur serveur", error })
    console.log(error)
  }
}

const getCartonPiece = async (req, res) => {
  const { item_id, model_id, service_id } = req.params
  try {
    const cartons = await prisma.stock_carton.findMany({
      where: {
        piece_id: parseInt(item_id),
        model_id: parseInt(model_id),
        service_id: parseInt(service_id)
      },
      orderBy: {
        numero_carton: 'asc'
      },

    })
    if (!cartons) {
      console.log("Zero carton trouvé")
      return res.status(404).json({ message: "Aucun carton trouvé pour cette pièce !" })
    }

    return res.status(200).json(cartons)
  } catch (error) {
    res.status(500).json({ message: "Erreur serveur", error })
    console.log(error)
  }
}

const getQuantitePiece = async (req, res) => {
  const { item_id, model_id, service_id } = req.params
  try {
    const quantite = await prisma.stock_piece.findFirst({
      where: {
        piece_id: parseInt(item_id),
        model_id: parseInt(model_id),
        service_id: parseInt(service_id),
      },
    })
    if (!quantite) {
      console.log("Stock pas encore initialisé")
      return res.status(404).json({ message: "Stock pas encore initialisé" })
    }

    return res.status(200).json(quantite.quantite)
  } catch (error) {
    res.status(500).json({ message: "Erreur serveur", error })
    console.log(error)
  }
}

const getAllOneQuantitePiece = async (req, res) => {
  const { id } = req.params;
  try {
    const stock = await prisma.stock_piece.findMany({
      where: {
        piece_id: parseInt(id),
      },
      orderBy: {
        id: 'desc',
      },
    })

    if (!stock) {
      return res.status(404).json({ message: "Aucune quantité trouvée !" })
    }

    return res.status(200).json(stock)
  } catch (error) {
    res.status(500).json({ message: "Erreur serveur", error })
    console.log(error)
  }
}

const getAllTypeMouvementStock = async (req, res) => {
  try {
    const types = await prisma.type_mouvement_stock.findMany({
      orderBy: { id: 'asc' },
    });

    res.status(200).json(types);
  } catch (error) {
    console.log("Error : ", error)
    res.status(500).json({ message: "Erreur lors de la récupération des types de mouvement stock", error });
  }
}

const getAllItemModels = async (req, res) => {
  try {
    const models = await prisma.items_models.findMany({
      orderBy: { item_id: 'asc' }
    })

    res.status(200).json(models);
  } catch (error) {
    res.status(500).json({ message: "Erreur lors de la récupération des modèles pièces ", error });
  }
}

const getAllItemServices = async (req, res) => {
  try {
    const services = await prisma.items_services.findMany({
      orderBy: { item_id: 'asc' }
    })

    res.status(200).json(services);
  } catch (error) {
    res.status(500).json({ message: "Erreur lors de la récupération des services pièces ", error });
  }
}

const getCartonStock = async (req, res) => {
  const { id } = req.params
  try {
    const cartons = await prisma.stock_carton.findMany({
      where: {
        stock_id: parseInt(id),
      },
      orderBy: {
        numero_carton: 'asc'
      },

    })
    if (!cartons) {
      console.log("Zero carton trouvé")
      return res.status(404).json({ message: "Aucun carton trouvé pour ce stock !" })
    }

    return res.status(200).json(cartons)
  } catch (error) {
    res.status(500).json({ message: "Erreur serveur", error })
    console.log(error)
  }
}

const getLotStock = async (req, res) => {
  const { id } = req.params
  try {
    const lot = await prisma.stock_lot.findMany({
      where: {
        stock_id: parseInt(id)
      },
      orderBy: {
        numero_lot: 'asc'
      },
    })
    if (!lot) {
      console.log("Zero lot trouvé")
      return res.status(404).json({ message: "Aucun lot trouvé pour ce stock !" })
    }

    return res.status(200).json(lot)
  } catch (error) {
    res.status(500).json({ message: "Erreur serveur", error })
    console.log(error)
  }
}

const getStockParPiece = async (req, res) => {
  const { id } = req.params;
  try {
    const stock = await prisma.stocks.findMany({
      where: {
        piece_id: parseInt(id),
      },
      orderBy: {
        id: 'desc',
      },
    })

    if (!stock) {
      return res.status(404).json({ message: "Stock introuvable !" })
    }

    return res.status(200).json(stock)
  } catch (error) {
    res.status(500).json({ message: "Erreur serveur", error })
    console.log(error)
  }
}

// const getAllUserTypeStocks = async (req, res) => {
//   const {
//     itemId,
//     modelId,
//     serviceId,
//   } = req.params

//   try {
//     const stockCreators = await prisma.users.findMany({
//       where: {
//         stocks_stocks_created_byTousers: {
//           some: {
//             piece_id: +itemId,
//             model_id: +modelId,
//             service_id: +serviceId,
//           },
//         },
//       },
//     });

//     const stockOwners = await prisma.users.findMany({
//       where: {
//         stock_owners: {
//           where: {
//             stocks: {
//               some: {
//                 piece_id: +itemId,
//                 model_id: +modelId,
//                 service_id: +serviceId,
//               },
//             },
//           },
//         },
//       },
//     })

//     const users = [...stockCreators, stockOwners]
//     console.log('Succès récupération des users')
//     return res.status(200).json(users);
//   } catch (error) {
//     console.log("Error : ", error)
//     res.status(500).json({ message: "Erreur lors de la récupération des utilisateurs par type de stock", error });
//   }
// }

const getAllUserTypeStocks = async (req, res) => {
  const { itemId, modelId, serviceId } = req.params;

  try {
    const users = await prisma.users.findMany({
      where: {
        OR: [
          {
            stocks_stocks_created_byTousers: {
              some: {
                piece_id: +itemId,
                model_id: +modelId,
                service_id: +serviceId,
              },
            },
          },
          {
            stock_owners: {
              some: {
                stocks: {
                  piece_id: +itemId,
                  model_id: +modelId,
                  service_id: +serviceId,
                },
              },
            },
          },
        ],
      },
    });

    console.log('Succès récupération des users');
    return res.status(200).json(users);
  } catch (error) {
    console.log("Error : ", error);
    res.status(500).json({ message: "Erreur lors de la récupération des utilisateurs par type de stock", error });
  }
};

const modifyStock = async (req, res) => {
  try {
    const { id } = req.params;
    const { code_stock, selectedOwner, selectedSubOwners, userId } = req.body;

    const stock = await prisma.stocks.findUnique({
      where: { id: parseInt(id) }
    })

    if (!stock) {
      console.error("Stock introuvable !")
      return res.status(404).json({ message: "Stock introuvable !" });
    }

    if (stock.is_deleted) {
      console.error("Stock supprimé !")
      return res.status(400).json({ message: "Stock supprimé !" });
    }

    const utilisateur = await prisma.users.findUnique({
      where: {
        id_user: parseInt(userId)
      }
    });

    if (!utilisateur) {
      console.error("Utilisateur introuvable !")
      return res.status(404).json({ message: "Utilisateur introuvable !" });
    }

    const operation = await prisma.$transaction(async (tx) => {
      await tx.stocks.update({
        where: { id: parseInt(id) },
        data: {
          code_stock,
          owner: parseInt(selectedOwner),
          updated_by: parseInt(userId),
          last_update: new Date(),
        }
      });

      // Wipe every existing owner/sub_owner row for this stock
      await tx.stock_owners.deleteMany({
        where: { stock_id: parseInt(id) }
      });

      await tx.stock_owners.create({
        data: {
          user_id: parseInt(selectedOwner),
          stock_id: parseInt(id),
          type: 'owner',
        }
      });

      const subOwners = Array.isArray(selectedSubOwners) ? selectedSubOwners : [];
      if (subOwners.length > 0) {
        await tx.stock_owners.createMany({
          data: subOwners
            .map(subId => parseInt(subId))
            .filter(subId => subId !== parseInt(selectedOwner)) // avoid owner/sub_owner overlap
            .map(subId => ({
              user_id: subId,
              stock_id: parseInt(id),
              type: 'sub_owner',
            })),
        });
      }

      return true;
    });

    console.log(`Stock ${id} modifié avec succès par ${utilisateur.username}.`)
    return res.status(200).json({
      message: `Stock ${id} modifié avec succès par ${utilisateur.username}.`,
      ...operation,
    });

  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Erreur lors de la modification du stock", error });
  }
}

// Mouvement manuel sur un stock (page détails du stock). Seul le mouvement « par pièce » (typeMouvement 5) existe.
// Les quantités sont recalculées côté serveur à partir du stock verrouillé (les valeurs envoyées par le client sont ignorées).
// Une sortie par pièce ne peut prendre que des pièces hors cartons : les cartons/lots se sortent par une demande.
const createMouvementStock = async (req, res) => {
  try {
    const {
      stockId,
    } = req.params;
    const {
      origine,
      destination,
      details,
      userId,
      typeMouvement,
      motif,
      commentaire,
    } = req.body;

    const utilisateur = await prisma.users.findUnique({
      where: {
        id_user: parseInt(userId)
      }
    });

    if (!utilisateur) {
      console.error("Utilisateur introuvable !");
      return res.status(404).json({ message: "Utilisateur introuvable !" });
    }

    const stock = await prisma.stocks.findUnique({
      where: { id: parseInt(stockId) },
      include: { stock_owners: true },
    });

    if (!stock) {
      console.error("Stock introuvable !");
      return res.status(404).json({ message: "Stock introuvable !" });
    }

    if (stock.is_deleted) {
      console.error("Stock supprimé !");
      return res.status(400).json({ message: "Stock supprimé !" });
    }

    const estResponsable = stock.owner === utilisateur.id_user ||
      stock.created_by === utilisateur.id_user ||
      stock.stock_owners.some((o) => o.user_id === utilisateur.id_user)
    if (!estResponsable) {
      return res.status(403).json({ message: "Vous n'êtes ni propriétaire, ni co-propriétaire, ni créateur de ce stock." });
    }

    if (!['entree', 'sortie'].includes(typeMouvement)) {
      return res.status(400).json({ message: "Type de mouvement invalide (entrée ou sortie)." });
    }

    const detailsMouvement = (typeof details === "string" ? JSON.parse(details) : details) || {};
    if (Number(detailsMouvement.typeMouvement) !== 5) {
      return res.status(400).json({ message: "Seul le mouvement par pièce est disponible depuis la page du stock." });
    }

    const quantite = Number(detailsMouvement.quantiteMouvement)
    if (!Number.isInteger(quantite) || quantite < 1) {
      return res.status(400).json({ message: "Quantité invalide !" });
    }

    if (!motif || !String(motif).trim()) {
      return res.status(400).json({ message: "Veuillez préciser le motif !" });
    }

    const dateAction = new Date();

    const operation = await prisma.$transaction(async (tx) => {
      // Verrou sur le stock (UPDATE en premier) puis valeurs à jour
      const stockVerrouille = await tx.stocks.update({
        where: { id: stock.id },
        data: { last_update: dateAction, updated_by: utilisateur.id_user },
      })
      const initial = stockVerrouille.quantite_piece ?? 0

      let final = initial + quantite
      if (typeMouvement === 'sortie') {
        const cartons = await tx.stock_carton.findMany({
          where: { stock_id: stock.id, is_deleted: false },
          select: { quantite_totale_piece: true },
        })
        const dansCartons = cartons.reduce((acc, c) => acc + (c.quantite_totale_piece || 0), 0)
        const horsCartons = Math.max(0, initial - dansCartons)
        if (quantite > horsCartons) {
          const err = new Error(dansCartons > 0
            ? `Stock insuffisant hors cartons : ${horsCartons} pièce(s) disponible(s). Les pièces en cartons/lots se sortent par une demande.`
            : `Stock insuffisant : ${initial} pièce(s) disponible(s).`)
          err.status = 409
          throw err
        }
        final = initial - quantite
      }

      const detailsServeur = {
        ...detailsMouvement,
        typeMouvement: 5,
        stockInitialPiece: initial,
        quantiteMouvement: quantite,
        stockFinalPiece: final,
      }

      const mouvement = await tx.mouvement_stock.create({
        data: {
          type: typeMouvement,
          mouvement: 5,
          created_at: dateAction,
          stock_id: stock.id,
          piece_id: stock.piece_id,
          origine: typeMouvement === 'entree' ? origine : null,
          destination: typeMouvement === 'sortie' ? destination : null,
          service_origine: typeMouvement === 'sortie' ? stock.service_id : null,
          service_destination: typeMouvement === 'entree' ? stock.service_id : null,
          model_id: stock.model_id,
          stock_initial: initial,
          quantite,
          stock_final: final,
          quantite_totale_piece: final,
          motif,
          commentaire,
          details_mouvement: JSON.stringify(detailsServeur),
          created_by: utilisateur.id_user,
        }
      });

      await tx.stocks.update({
        where: { id: stock.id },
        data: { quantite_piece: final },
      });

      return {
        mouvement,
      }
    })

    console.log(`Mouvement de stock créé avec succès par ${utilisateur.username}.`)
    return res.status(201).json({
      message: `Mouvement de stock créé avec succès par ${utilisateur.username}.`,
      operation,
    });
  } catch (error) {
    if (error.status) {
      console.error(error.message);
      return res.status(error.status).json({ message: error.message });
    }
    console.error(error);
    return res.status(500).json({ message: "Erreur lors de la création du mouvement de stock", error });
  }
}

const getAllStockSubOwners = async (req, res) => {
  try {
    const { stockId } = req.params;

    const subOwners = await prisma.stock_owners.findMany({
      where: {
        stock_id: parseInt(stockId),
        type: 'sub_owner',
      },
      include: {
        users: true,
      },
    });
    return res.status(200).json(subOwners);
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Erreur lors de la récupération des sous-propriétaires du stock", error });
  }
}

module.exports = {
  setStockPiece,
  getAllItems,
  getAllModels,
  addPiece,
  getAllMouvementStock,
  getPiece,
  modifyPiece,
  getLotPiece,
  getCartonLot,
  getCartonPiece,
  getItemModels,
  getItemServices,
  getQuantitePiece,
  getAllTypeMouvementStock,
  setStockCarton,
  setStockPieceCarton,
  setStockLot,
  setStockCartonLot,
  getOneMouvement,
  createStock,
  getAllStocks,
  getAllItemModels,
  getAllItemServices,
  getOneStock,
  getCartonStock,
  getLotStock,
  getOneStockMouvements,
  getStockParPiece,
  getAllOneQuantitePiece,
  setStockSn,
  getAllUserTypeStocks,
  modifyStock,
  createMouvementStock,
  getAllStockSubOwners,
}
